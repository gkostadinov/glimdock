# Corresponding firmware source and practical relink materials

This bundle accompanies the downloadable Glimdock ESP32-S3 Waveshare V1 image.
Original application source is MIT licensed. Arduino core/libraries retain
LGPL-2.1-or-later and individual notices; ESP-IDF, LVGL, fonts, ArduinoJson and
compiler runtime terms are retained under LICENSES and dependencies.

Install the PlatformIO Core version in build-inventory.json, then run:

    python3 rebuild.py

The helper creates an isolated package cache, installs the pinned platform and
checks its exact Arduino framework version. It overlays the supplied Arduino
source (including any modifications you make), builds the vendored LVGL and
ArduinoJson source, and links a public unpaired application. No flash action runs.

To rebuild the LGPL libraries and relink the original application object files:

    python3 rebuild.py --preserve-application-objects

The relink hook replaces only original application objects immediately before
linking. Arduino core and libraries are rebuilt from your modified sources.
Original object/archive files, a linker map and the actual compile/link commands
are supplied under relink/. Paths in command/map text are represented by
${PROJECT_DIR}, ${FRAMEWORK_DIR}, ${PACKAGES_DIR}, ${BUNDLE_PROJECT} and
${USER_HOME}; the helper
uses current absolute paths automatically. The original core archive is a
reference; it is not substituted for your rebuilt, modified core.

The package excludes private Wi-Fi/token defaults and runtime snapshots. The
GLIMDOCK_PUBLIC_FIRMWARE build flag deliberately starts new displays unpaired.
Saved display pairing in NVS survives USB updates. USB flashing is available
using esptool or the collector Web Serial interface; no signing key or locked
bootloader prevents installation of a modified image. Modification and reverse
engineering for debugging library changes are permitted by the retained terms.

ESP-IDF SDK/toolchain executables are fetched as pinned PlatformIO packages,
not duplicated here. Exact installed package metadata, SDK library names, SDK
configuration and linker scripts accompany the sources. The included notices
distinguish linked libraries from an overinclusive SDK license inventory.
